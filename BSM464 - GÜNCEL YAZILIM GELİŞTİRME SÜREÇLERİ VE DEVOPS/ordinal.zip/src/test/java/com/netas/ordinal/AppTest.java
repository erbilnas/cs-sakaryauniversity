package com.netas.ordinal;

import static org.assertj.core.api.Assertions.*;

import org.junit.Test;

/**
 * AppTest
 */
public class AppTest {

  @Test
  public void dummy() {
    assertThat(true).isTrue();
  }

  
}