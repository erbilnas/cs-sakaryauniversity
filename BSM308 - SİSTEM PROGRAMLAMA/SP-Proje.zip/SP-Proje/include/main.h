
// Komut icin maksimum token sayisi.
#define MAXTOKEN 256

// Kullanici inputunun maksimum sayisi.
#define MAXLINE 1024
int sayimi(char number[]);
int builtin_add(char **args);
int builtin_search(char **args);
int builtin_write(char **args);
int builtin_print(char **args);
int builtin_quit(char **args);
int builtin_help(char **args);
int builtinadeti();
int clearMemory();

