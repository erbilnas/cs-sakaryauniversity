Program calıstırırken dosya okumak istenirse "./program.o < input.txt" tarzı yazılmalıdır.
Dosya okuduktan sonra yeni siparis eklenip yeni dosyaya yazılcagı zaman bir sonraki kullanım icin hazırlanan syntax da kaydedilir.

Grup Bilgisi

b151210053 - Erbil Nas
b151210098 - Alperen Kaymak
b151210113 - Umut Tosun
g131210011 - Abdulsamet Sazak
